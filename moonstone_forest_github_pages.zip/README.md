# Moonstone Forest on GitHub Pages

This package contains the ready-built web game and a GitHub Actions workflow that publishes it to GitHub Pages when pushed to the `main` branch.

Create a GitHub repository, upload the contents of this folder, and push to `main`. The workflow will publish the game and show its web address in the Actions run.

Game: collect all three Moon Gems, avoid the forest spirit, then reach the portal.
